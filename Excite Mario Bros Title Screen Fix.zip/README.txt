
Patches gray title screen issue.

Apply IPS to Super Mario Bros 1 US ROM (MD5 811b027eaf99c2def7b933c5208636de)

You can use this to apply the patch:
https://bbbradsmith.github.io/ipstool/

Original hack available here: https://www.romhacking.net/hacks/1522/

/threecreepio