
- Patches Bus Conflict on SMB vs Airman

Apply IPS to Super Mario Bros 1 US ROM.

Original hack available here: https://www.romhacking.net/hacks/1589/
